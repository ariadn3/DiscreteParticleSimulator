This data was removed to reduce the file size of the ZIP archive.

Please contact us for the information - or you can manually run the default testcase in
print mode for all three implementations and then execute the divergenceAnalysis.py script.