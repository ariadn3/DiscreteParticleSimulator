mkdir test_in
mkdir test_out
python3 generate.py
