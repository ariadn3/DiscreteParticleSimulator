gcc source/*.h
gcc -fopenmp source/*.c -lm
